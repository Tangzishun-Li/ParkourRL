#include "GameEnv.h"
#include <cstdlib>
#include <ctime>
#include <algorithm>

// ==========================================
// RL 超参数配置区 (多级惩罚版)
// ==========================================
#define REWARD_PASS 10.0f  // 通过奖励
#define REWARD_DEATH -0.0f // 死亡额外惩罚
#define REWARD_STEP 0.01f  // 步数奖励
#define DAMAGE_TAKEN 10    // 每次扣血
#define INITIAL_BLOOD 100  // 初始血量

// [新增] 多级惩罚定义
#define PENALTY_SEVERE -50.0f   // 重度惩罚：反向操作 (如对着空中的怪跳)
#define PENALTY_MODERATE -20.0f // 中度惩罚：不操作 (躺平)
#define PENALTY_SLIGHT -10.0f   // 轻微惩罚：操作正确但时机不对 (勇气奖励)

// 接口实现
float GameEnv::get_reward_pass() { return REWARD_PASS; }
float GameEnv::get_reward_hit() { return PENALTY_MODERATE; }
float GameEnv::get_reward_death() { return REWARD_DEATH; }
int GameEnv::get_damage_taken() { return DAMAGE_TAKEN; }

// 构造函数
GameEnv::GameEnv()
{
    bgSpeed[0] = 1;
    bgSpeed[1] = 2;
    bgSpeed[2] = 4;
    srand((unsigned int)time(NULL));
    reset();
}

void GameEnv::reset()
{
    heroX = (int)(1012 * 0.5 - HERO_W * 0.5);
    heroY = 345 - HERO_H;

    heroBlood = INITIAL_BLOOD;
    score = 0;
    heroIndex = 0;
    heroJump = false;
    heroDown = false;
    heroJumpOff = -6;
    jumpHeightMax = 345 - HERO_H - 120;

    frameCount = 0;
    currentStepPenalty = 0.0f; // 重置惩罚变量

    for (int i = 0; i < 3; i++)
        bgX[i] = 0;
    for (int i = 0; i < 10; i++)
        obstacles[i].exist = false;

    // 构建固定关卡脚本
    levelScript.clear();
    scriptIndex = 0;

    int currentFrame = 60;
    int gap = 180;

    // 0=乌龟, 1=狮子, 2=挂钩
    int patterns[] = {0, 1, 2, 0, 0, 2, 1, 1, 2, 2};
    int patternLen = 10;

    for (int i = 0; i < 200; i++)
    {
        SpawnEvent e;
        e.frame = currentFrame;
        e.type = patterns[i % patternLen];
        levelScript.push_back(e);
        currentFrame += gap;
    }
}

StepResult GameEnv::step(int action)
{
    int oldScore = score;
    int oldBlood = heroBlood;

    // [新增] 每一步开始前重置当帧惩罚
    currentStepPenalty = 0.0f;

    // 动作处理逻辑
    if (action == 1 && !heroJump && !heroDown) // 跳
    {
        heroJump = true;
        heroJumpOff = -6;
    }
    else if (action == 2 && !heroJump && !heroDown) // 蹲
    {
        heroDown = true;
        heroIndex = 0;
    }

    update_physics(); // 这里面会调用 check_hit 更新 currentStepPenalty

    // --- [核心修改] 奖励判定逻辑 ---
    // 修改说明：将受伤判定移到死亡判定之前，确保 Agent 知道自己是因为什么操作失误而死的

    float r = REWARD_STEP;

    // 1. 优先判定通过得分
    if (score > oldScore)
    {
        r = REWARD_PASS;
    }

    // 2. 其次判定是否受伤 (使用智能裁判的具体惩罚覆盖当前奖励)
    if (heroBlood < oldBlood)
    {
        // 如果扣血了，优先使用 check_hit 计算出的 currentStepPenalty (例如 -20)
        // 这样即使这一帧死了，r 也是 -20，而不是被死亡的 -50 直接覆盖成不知道原因
        r = (currentStepPenalty != 0.0f) ? currentStepPenalty : PENALTY_MODERATE;
    }

    // 3. 最后判定死亡 (叠加逻辑)
    if (heroBlood <= 0)
    {
        // 死亡惩罚叠加在刚才的动作惩罚上
        // 结果可能是：-20 (动作失误) + -50 (死亡) = -70
        r += REWARD_DEATH;
    }

    return {get_obs(), r, heroBlood <= 0, score};
}

void GameEnv::update_physics()
{
    // 1. 背景滚动
    for (int i = 0; i < 3; i++)
    {
        bgX[i] -= bgSpeed[i];
        if (bgX[i] < -1012)
            bgX[i] = 0;
    }

    // 2. 英雄跳跃逻辑
    if (heroJump)
    {
        if (heroY < jumpHeightMax)
            heroJumpOff = 6;
        heroY += heroJumpOff;
        if (heroY > 345 - HERO_H)
        {
            heroJump = false;
            heroJumpOff = -6;
        }
    }
    // 3. 英雄下蹲逻辑
    else if (heroDown)
    {
        static int count = 0;
        int delays[2] = {8, 40};
        count++;
        if (count >= delays[heroIndex])
        {
            count = 0;
            heroIndex++;
            if (heroIndex >= 2)
            {
                heroIndex = 0;
                heroDown = false;
            }
        }
    }
    else
        heroIndex = (heroIndex + 1) % 12;

    // 4. 障碍物生成 (保持固定脚本逻辑)
    frameCount++;
    if (scriptIndex < levelScript.size() && frameCount >= levelScript[scriptIndex].frame)
    {
        create_obstacle(levelScript[scriptIndex].type);
        scriptIndex++;
    }

    // 5. 障碍物移动与计分
    for (int i = 0; i < 10; i++)
    {
        if (obstacles[i].exist)
        {
            obstacles[i].x -= (obstacles[i].speed + bgSpeed[2]);
            int type_idx = (obstacles[i].type >= 2) ? 2 : obstacles[i].type;

            if (obstacles[i].x < -(OBS_W[type_idx] * 2))
                obstacles[i].exist = false;

            obstacles[i].imgindex++;

            if (!obstacles[i].passed && !obstacles[i].hited &&
                (obstacles[i].x + OBS_W[type_idx] < heroX))
            {
                score++;
                obstacles[i].passed = true;
            }
        }
    }
    check_hit();
}

void GameEnv::create_obstacle(int type)
{
    int i;
    for (i = 0; i < 10; i++)
        if (!obstacles[i].exist)
            break;
    if (i >= 10)
        return;

    obstacles[i].exist = true;
    obstacles[i].hited = false;
    obstacles[i].passed = false;
    obstacles[i].imgindex = 0;
    obstacles[i].type = type;
    obstacles[i].x = 1012;

    if (obstacles[i].type >= 2) // 挂钩
    {
        obstacles[i].y = 0;
        obstacles[i].speed = 0;
    }
    else // 地面
    {
        int type_idx = obstacles[i].type;
        obstacles[i].y = 345 + 5 - OBS_H[type_idx];
        obstacles[i].speed = (obstacles[i].type == 1) ? 4 : 0;
    }
}

// ==========================================
// 核心逻辑：智能裁判系统 check_hit (保持不变)
// ==========================================
void GameEnv::check_hit()
{
    int off = 10;
    bool intersect = false; // 标记是否发生碰撞
    int hitType = -1;       // 记录撞到的障碍物类型

    for (int i = 0; i < 10; i++)
    {
        if (obstacles[i].exist && !obstacles[i].hited)
        {
            int h_x, h_y, h_w, h_h;

            if (!heroDown)
            {
                h_x = heroX + off;
                h_y = heroY + 10;
                h_w = HERO_W - off * 2;
                h_h = HERO_H - 10;
            }
            else
            {
                h_x = heroX + off;
                h_y = 345 - HERO_DOWN_H + 10;
                h_w = HERO_DOWN_W - off * 2;
                h_h = HERO_DOWN_H - 10;
            }

            int type_idx = (obstacles[i].type >= 2) ? 2 : obstacles[i].type;
            int obs_x = obstacles[i].x + off;
            int obs_y = obstacles[i].y;
            int obs_w = OBS_W[type_idx] - off * 2;
            int obs_h = OBS_H[type_idx] - 10;

            if (rectIntersect(h_x, h_y, h_w, h_h, obs_x, obs_y, obs_w, obs_h))
            {
                heroBlood -= DAMAGE_TAKEN;
                obstacles[i].hited = true;
                intersect = true;
                hitType = obstacles[i].type; // 记录类型
                break;
            }
        }
    }

    // [核心] 智能判罚逻辑
    if (intersect)
    {
        if (hitType == 0 || hitType == 1)
        {
            if (heroDown)
                currentStepPenalty = PENALTY_SEVERE;
            else if (!heroJump && !heroDown)
                currentStepPenalty = PENALTY_MODERATE;
            else if (heroJump)
                currentStepPenalty = PENALTY_SLIGHT;
        }
        else if (hitType >= 2)
        {
            if (heroJump)
                currentStepPenalty = PENALTY_SEVERE;
            else if (!heroJump && !heroDown)
                currentStepPenalty = PENALTY_MODERATE;
            else if (heroDown)
                currentStepPenalty = PENALTY_SLIGHT;
        }
    }
}

bool GameEnv::rectIntersect(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2)
{
    if (x1 + w1 < x2)
        return false;
    if (x1 > x2 + w2)
        return false;
    if (y1 + h1 < y2)
        return false;
    if (y1 > y2 + h2)
        return false;
    return true;
}

std::vector<float> GameEnv::get_obs()
{
    float nearest_dist = 1.0f;
    float nearest_y = 0.0f;
    float relative_speed = 0.0f;

    for (int i = 0; i < 10; i++)
    {
        if (obstacles[i].exist && obstacles[i].x > heroX)
        {
            nearest_dist = (float)(obstacles[i].x - heroX) / 1012.0f;
            nearest_y = (float)obstacles[i].y / 396.0f;
            float closing_speed = (float)(obstacles[i].speed + bgSpeed[2]);
            relative_speed = closing_speed / 10.0f;
            break;
        }
    }

    if (relative_speed == 0.0f)
        relative_speed = (float)bgSpeed[2] / 20.0f;

    return {
        (float)heroY / 396.0f,
        nearest_dist,
        nearest_y,
        (heroJump ? 1.0f : 0.0f),
        (heroDown ? 1.0f : 0.0f),
        relative_speed};
}

RenderData GameEnv::get_render_data()
{
    RenderData data;
    data.heroX = heroX;
    data.heroY = heroY;
    data.heroIndex = heroIndex;
    data.heroDown = heroDown;
    data.score = score;
    data.heroBlood = heroBlood;

    for (int x : bgX)
        data.bgX.push_back(x);

    for (int i = 0; i < 10; i++)
    {
        if (obstacles[i].exist)
        {
            data.obstacles.push_back({obstacles[i].type, obstacles[i].x, obstacles[i].y, obstacles[i].imgindex});
        }
    }
    return data;
}